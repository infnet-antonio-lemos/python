def super_potencia(base, expoente):
    return base ** expoente